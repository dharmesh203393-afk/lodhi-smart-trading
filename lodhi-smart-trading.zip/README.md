# Lodhi Smart Trading — NIFTY 50 Dashboard

Mobile-friendly static dashboard for educational/demo use.

## What's included
- Simulated NIFTY-style price and candlestick chart
- Demo-only CALL / PUT / NO TRADE trend panel
- Sample support/resistance levels
- Synthetic option-chain table, OI changes and PCR
- Example entry / stop-loss / target calculator
- Explicit demo-data warnings
- GitHub Pages deployment workflow

## Important data notice
**No live exchange feed is connected.** Prices, candles, OI, PCR, VIX, probabilities, levels and signals are synthetic placeholders. Do not use them to place trades. A real implementation needs a licensed/reliable market-data provider and a secure backend; never put private API keys in frontend code.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a repository named `lodhi-smart-trading` on your GitHub account.
2. Upload all files from this project (including `.github/workflows/deploy-pages.yml`).
3. Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
4. The workflow deploys the static site when you push to the `main` branch. Check **Actions** for deployment status.
5. Your public URL will be `https://YOUR-GITHUB-USERNAME.github.io/lodhi-smart-trading/`.

## Next steps for live data
Choose a market-data vendor that supports Indian indices and options data, confirm exchange licensing and permitted display/use, and proxy requests through a backend. Keep secrets in GitHub Actions secrets or server environment variables—not in browser JavaScript.
